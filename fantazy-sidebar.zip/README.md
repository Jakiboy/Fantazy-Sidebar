# Fantazy-Sidebar
Fantazy Sidebar Makes wordpress's sidebar floatable, with less code &amp; more performance.
