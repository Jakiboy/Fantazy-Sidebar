=== Fantazy Sidebar ===
Contributors: jihad-sinnaour
Donate link: http://jakiboy.github.io/Fantazy-Sidebar/
Tags: sidebar, floating, ads, wordpress
Requires at least: 3.0
Tested up to: 4.2.2
Stable tag: 1.4.4
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Fantazy Sidebar Makes wordpress's sidebar floatable, with less code & more performance.

== Description ==

First thing i have to notify, is that this plugin is not a pure release, 
means that its just a new version of an old deprecated wordpress plugin : strx floating sidebar,
so i decided to refresh this plugin by a new clean version compatible with the latest wordpress core systeme,
with less code, and new wordpress functions, for a better website's security.
Fantazy Sidebar, keeps the same optionalities as the old verion, but i have deleted some debuging non useful functions
to make the plugin more simple, and i also deleted all ads inside the plugin backend

now if your sidebare is too short comparing to your content, Fantazy Sidebar w'll make you sidebar floatable

== Installation ==

1. From your plugin's admin panel, click on Add New /  then upload the .zip file `fantazy-sidebar.zip`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings / Fantazy Sidbar, then select your custom options

== Frequently Asked Questions ==

Waiting for your questions


== Screenshots ==

1. layout_area.png : how Fantazy Sidbar works


== Changelog ==

= 1.5 =
first clean release version


== Upgrade Notice ==

= 1.5 =
first clean release version